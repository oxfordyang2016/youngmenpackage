from distutils.core import setup
setup(
  name = 'youngmenpackage',
  packages = ['youngmenpackage'], # this must be the same as the name above
  version = '0.3',
  description = 'A tutorial lib',
  author = 'yangming',
  author_email = 'yang756260386@gmail.com',
  url = 'https://github.com/oxfordyang2016/youngmenpackage',
  download_url = 'https://github.com/oxfordyang2016/youngmenpackage/tarball/0.2',
  keywords = ['add', 'sub', 'tests'], 
  classifiers = [],
)
